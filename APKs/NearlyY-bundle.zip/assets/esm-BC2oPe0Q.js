const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CtU97x1Q.js","./index-BfdPiNTL.js","./index-CelEvW65.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-BfdPiNTL.js";const o=r("App",{web:()=>p(()=>import("./web-CtU97x1Q.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
