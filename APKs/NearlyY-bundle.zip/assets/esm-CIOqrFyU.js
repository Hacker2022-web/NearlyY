const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CsXQ6NBR.js","./index-CY_f1yfR.js","./index-B3jBiaY-.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-CY_f1yfR.js";const o=r("App",{web:()=>p(()=>import("./web-CsXQ6NBR.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
