const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dok_uPWM.js","./index-CiW1o7mD.js","./index-CelEvW65.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-CiW1o7mD.js";const o=r("App",{web:()=>p(()=>import("./web-Dok_uPWM.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
